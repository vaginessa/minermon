----------------------
minermon 0.1, Jan 2018
----------------------

This tool simply shows the most important information about your GPU so you can see
if everything is fine. Every miner faces the situation when cards goes offline or GPU errors occurs. 
It obviously leads to the lose of performance. Most of you are using ugly .bat's to detect these moments,
while minermon uses native Nvidia API to check the status of all GPUs that presents in your system. 
When something goes wrong it sends a command to safely reboot your PC. 
No confgis, no command line arguments, no personal involvment, just run and relax!

Built for x64 Win, Nvidia only.


##############
### DONATE ###
##############

BTC: 1Cvz82y2sKz3tSbpH3feC7sCZzkevKYv3x
ZEC: t1NeMBmoSXz7TAGpQZpTP5QFaDcz2D92bwe
ZCL: t1hCPdkgnxaPVh1LbobqFsk1vb3j6vkov7K

intercepter.mail@gmail.com